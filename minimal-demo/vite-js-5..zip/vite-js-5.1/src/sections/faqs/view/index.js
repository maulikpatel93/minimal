export { default as FaqsView } from './faqs-view';
