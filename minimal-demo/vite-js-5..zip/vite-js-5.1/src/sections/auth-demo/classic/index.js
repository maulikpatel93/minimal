export { default as ClassicLoginView } from './classic-login-view';
export { default as ClassicVerifyView } from './classic-verify-view';
export { default as ClassicRegisterView } from './classic-register-view';
export { default as ClassicNewPasswordView } from './classic-new-password-view';
export { default as ClassicForgotPasswordView } from './classic-forgot-password-view';
