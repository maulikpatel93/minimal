export { default as ProductEditView } from './product-edit-view';
export { default as ProductShopView } from './product-shop-view';
export { default as ProductListView } from './product-list-view';
export { default as ProductCreateView } from './product-create-view';
export { default as ProductDetailsView } from './product-details-view';
export { default as ProductShopDetailsView } from './product-shop-details-view';
