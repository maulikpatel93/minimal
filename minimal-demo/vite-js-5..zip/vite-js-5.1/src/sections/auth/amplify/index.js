export { default as AmplifyLoginView } from './amplify-login-view';
export { default as AmplifyVerifyView } from './amplify-verify-view';
export { default as AmplifyRegisterView } from './amplify-register-view';
export { default as AmplifyNewPasswordView } from './amplify-new-password-view';
export { default as AmplifyForgotPasswordView } from './amplify-forgot-password-view';
