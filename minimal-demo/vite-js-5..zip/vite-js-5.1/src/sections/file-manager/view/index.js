export { default as FileManagerView } from './file-manager-view';
