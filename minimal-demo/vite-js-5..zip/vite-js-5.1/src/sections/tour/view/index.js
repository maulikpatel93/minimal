export { default as TourListView } from './tour-list-view';
export { default as TourEditView } from './tour-edit-view';
export { default as TourCreateView } from './tour-create-view';
export { default as TourDetailsView } from './tour-details-view';
