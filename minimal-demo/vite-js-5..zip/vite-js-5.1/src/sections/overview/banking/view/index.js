export { default as OverviewBankingView } from './overview-banking-view';
